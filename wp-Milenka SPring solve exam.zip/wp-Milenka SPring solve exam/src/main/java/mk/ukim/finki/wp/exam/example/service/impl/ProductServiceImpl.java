package mk.ukim.finki.wp.exam.example.service.impl;


import lombok.AllArgsConstructor;
import mk.ukim.finki.wp.exam.example.model.Category;
import mk.ukim.finki.wp.exam.example.model.Product;
import mk.ukim.finki.wp.exam.example.model.exceptions.InvalidCategoryIdException;
import mk.ukim.finki.wp.exam.example.model.exceptions.InvalidProductIdException;
import mk.ukim.finki.wp.exam.example.repository.CategoryRepository;
import mk.ukim.finki.wp.exam.example.repository.ProductRepository;
import mk.ukim.finki.wp.exam.example.service.ProductService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public List<Product> listAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product findById(Long id) {
        return productRepository.findById(id).orElseThrow(InvalidProductIdException::new);
    }

    @Override
    public Product create(String name, Double price, Integer quantity, List<Long> categories) {
        List<Category> categories1 = categoryRepository.findAllById(categories);
        Product product = new Product(name, price, quantity, categories1);
        return productRepository.save(product);
    }

    @Override
    public Product update(Long id, String name, Double price, Integer quantity, List<Long> categories) {
        Product product = findById(id);
        List<Category> categories1 = categoryRepository.findAllById(categories);
        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setCategories(categories1);

        return productRepository.save(product);

    }

    @Override
    public Product delete(Long id) {
        Product product = findById(id);
        productRepository.deleteById(id);
        return product;
    }

    @Override
    public List<Product> listProductsByNameAndCategory(String name, Long categoryId) {

        String namepattern = "%" + name + "%";

        Category category = categoryId != null ? categoryRepository.findById(categoryId).orElseThrow(InvalidCategoryIdException::new) : null;

        String categorypattern = "%" + category + "%";
        if (name != null && category != null) {
            return productRepository.findAllByNameLikeAndAndCategoriesContaining(namepattern, category);

        }

        if (name != null) {
            return productRepository.findAllByNameLike(namepattern);
        }
        if (category != null) {
            return productRepository.findAllByCategoriesContaining(category);
        }

        return listAllProducts();
    }
}
