package mk.ukim.finki.wp.exam.example.model.exceptions;

public class InvalidCategoryIdException extends RuntimeException {
}
