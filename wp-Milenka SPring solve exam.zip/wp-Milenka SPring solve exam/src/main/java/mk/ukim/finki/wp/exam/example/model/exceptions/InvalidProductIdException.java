package mk.ukim.finki.wp.exam.example.model.exceptions;

public class InvalidProductIdException extends RuntimeException {
}
